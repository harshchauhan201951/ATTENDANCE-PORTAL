"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "../../lib/supabase";

type DashboardCard = {
  icon: string;
  title: string;
  description: string;
  path: string;
  className: string;
};

type Announcement = {
  id: number;
  title: string;
  message: string;
  created_at: string;
  likeCount: number;
  likedByMe: boolean;
};

export default function StudentDashboardPage() {
  const router = useRouter();

  const [studentName, setStudentName] = useState("Student");
  const [username, setUsername] = useState("");
  const [studentId, setStudentId] = useState<number | null>(null);
  const [profileImage, setProfileImage] = useState<string | null>(null);
  const [time, setTime] = useState("");
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [announcementLoading, setAnnouncementLoading] = useState(true);
  const [likingId, setLikingId] = useState<number | null>(null);

  useEffect(() => {
    initializeStudent();
    updateTime();

    const interval = setInterval(updateTime, 1000);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (announcements.length === 0) {
      return;
    }

    const interval = setInterval(() => {
      setAnnouncements((previous) => [...previous]);
    }, 60 * 1000);

    return () => clearInterval(interval);
  }, [announcements.length]);

  async function initializeStudent() {
    const name =
      localStorage.getItem("studentName") ||
      localStorage.getItem("student_name") ||
      "Student";

    const savedUsername =
      localStorage.getItem("student_username") ||
      localStorage.getItem("studentUsername") ||
      "";

    const savedStudentId = localStorage.getItem("studentId");

    setStudentName(name);
    setUsername(savedUsername);

    if (savedUsername) {
      const resolvedId = await resolveStudentId(savedUsername);

      if (resolvedId !== null) {
        setStudentId(resolvedId);

        localStorage.setItem("studentId", String(resolvedId));

        await loadStudentProfile(resolvedId, savedUsername);
        await loadAnnouncements(resolvedId);
        await registerPushNotifications(resolvedId);

        return;
      }
    }

    if (savedStudentId) {
      const parsedId = Number(savedStudentId);

      if (!Number.isNaN(parsedId) && parsedId > 0) {
        setStudentId(parsedId);

        await loadStudentProfile(parsedId, savedUsername);
        await loadAnnouncements(parsedId);
        await registerPushNotifications(parsedId);

        return;
      }
    }

    setStudentId(null);
    setProfileImage(null);

    await loadAnnouncements(null);
  }

  async function resolveStudentId(
    studentUsername: string
  ): Promise<number | null> {
    try {
      const { data, error } = await supabase
        .from("students")
        .select("id")
        .eq("student_username", studentUsername)
        .maybeSingle();

      if (error) {
        console.error("Student ID lookup error:", error);
        return null;
      }

      if (!data?.id) {
        console.error(
          "Student ID not found for username:",
          studentUsername
        );
        return null;
      }

      return Number(data.id);
    } catch (error) {
      console.error(
        "Unexpected student ID lookup error:",
        error
      );

      return null;
    }
  }

  async function loadStudentProfile(
    currentStudentId: number,
    currentUsername: string
  ) {
    try {
      let query = supabase
        .from("students")
        .select("profile_image_url");

      if (currentStudentId) {
        query = query.eq("id", currentStudentId);
      } else if (currentUsername) {
        query = query.eq(
          "student_username",
          currentUsername
        );
      } else {
        setProfileImage(null);
        return;
      }

      const { data, error } = await query.maybeSingle();

      if (error) {
        console.error(
          "Student profile image loading error:",
          error
        );

        setProfileImage(null);
        return;
      }

      if (!data) {
        setProfileImage(null);
        return;
      }

      const imageUrl =
        typeof data.profile_image_url === "string" &&
        data.profile_image_url.trim() !== ""
          ? data.profile_image_url.trim()
          : null;

      setProfileImage(imageUrl);
    } catch (error) {
      console.error(
        "Unexpected student profile image loading error:",
        error
      );

      setProfileImage(null);
    }
  }

  async function registerPushNotifications(
    currentStudentId: number
  ) {
    try {
      if (typeof window === "undefined") {
        return;
      }

      if (!("serviceWorker" in navigator)) {
        console.warn(
          "Service Worker is not supported by this browser."
        );
        return;
      }

      if (!("PushManager" in window)) {
        console.warn(
          "Push notifications are not supported by this browser."
        );
        return;
      }

      if (!("Notification" in window)) {
        console.warn(
          "Notifications are not supported by this browser."
        );
        return;
      }

      await navigator.serviceWorker.register("/sw.js", {
        scope: "/",
      });

      const registration =
        await navigator.serviceWorker.ready;

      if (!registration.active) {
        console.warn(
          "Service Worker is still not active."
        );
        return;
      }

      let permission =
        Notification.permission;

      if (permission === "default") {
        permission =
          await Notification.requestPermission();
      }

      if (permission !== "granted") {
        console.warn(
          "Notification permission was not granted."
        );
        return;
      }

      let subscription =
        await registration.pushManager.getSubscription();

      if (!subscription) {
        const vapidPublicKey =
          process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY;

        if (!vapidPublicKey) {
          console.error(
            "NEXT_PUBLIC_VAPID_PUBLIC_KEY is missing."
          );
          return;
        }

        const decodedKey =
          urlBase64ToUint8Array(
            vapidPublicKey
          );

        const applicationServerKey =
          new ArrayBuffer(
            decodedKey.byteLength
          );

        new Uint8Array(
          applicationServerKey
        ).set(decodedKey);

        subscription =
          await registration.pushManager.subscribe({
            userVisibleOnly: true,
            applicationServerKey,
          });
      }

      const response = await fetch(
        "/api/push/subscribe",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            studentId: currentStudentId,
            subscription:
              subscription.toJSON(),
          }),
        }
      );

      if (!response.ok) {
        const errorText =
          await response.text();

        console.error(
          "Push subscription API error:",
          errorText
        );

        return;
      }

      console.log(
        "Student push notification registration completed successfully."
      );
    } catch (error) {
      if (
        error instanceof DOMException &&
        error.name === "AbortError"
      ) {
        console.warn(
          "Push subscription was aborted because the Service Worker was not ready."
        );
        return;
      }

      console.error(
        "Push notification registration error:",
        error
      );
    }
  }

  function urlBase64ToUint8Array(
    base64String: string
  ): Uint8Array {
    const padding =
      "=".repeat(
        (4 - (base64String.length % 4)) % 4
      );

    const base64 =
      (base64String + padding)
        .replace(/-/g, "+")
        .replace(/_/g, "/");

    const rawData =
      window.atob(base64);

    const outputArray =
      new Uint8Array(rawData.length);

    for (
      let i = 0;
      i < rawData.length;
      ++i
    ) {
      outputArray[i] =
        rawData.charCodeAt(i);
    }

    return outputArray;
  }

  function updateTime() {
    setTime(
      new Date().toLocaleTimeString(
        "en-IN",
        {
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
        }
      )
    );
  }

  async function loadAnnouncements(
    currentStudentId: number | null
  ) {
    setAnnouncementLoading(true);

    try {
      const {
        data: announcementData,
        error: announcementError,
      } = await supabase
        .from("announcements")
        .select(
          "id, title, message, created_at"
        )
        .order("created_at", {
          ascending: false,
        });

      if (announcementError) {
        console.error(
          "Announcements loading error:",
          announcementError
        );

        setAnnouncements([]);
        return;
      }

      const announcementRows =
        announcementData || [];

      if (announcementRows.length === 0) {
        setAnnouncements([]);
        return;
      }

      const announcementIds =
        announcementRows.map(
          (announcement) =>
            announcement.id
        );

      const {
        data: likesData,
        error: likesError,
      } = await supabase
        .from("announcement_likes")
        .select(
          "announcement_id, student_id"
        )
        .in(
          "announcement_id",
          announcementIds
        );

      if (likesError) {
        console.error(
          "Announcement likes loading error:",
          likesError
        );
      }

      const likes = likesData || [];

      const formattedAnnouncements =
        announcementRows.map(
          (announcement) => {
            const announcementLikes =
              likes.filter(
                (like) =>
                  Number(
                    like.announcement_id
                  ) ===
                  Number(
                    announcement.id
                  )
              );

            const likedByMe =
              currentStudentId !== null &&
              announcementLikes.some(
                (like) =>
                  Number(
                    like.student_id
                  ) ===
                  Number(
                    currentStudentId
                  )
              );

            return {
              id: announcement.id,
              title:
                announcement.title,
              message:
                announcement.message,
              created_at:
                announcement.created_at,
              likeCount:
                announcementLikes.length,
              likedByMe,
            };
          }
        );

      setAnnouncements(
        formattedAnnouncements
      );
    } catch (error) {
      console.error(
        "Unexpected announcements error:",
        error
      );

      setAnnouncements([]);
    } finally {
      setAnnouncementLoading(false);
    }
  }

  async function toggleLike(
    announcementId: number
  ) {
    let currentStudentId =
      studentId;

    if (
      !currentStudentId &&
      username
    ) {
      const resolvedId =
        await resolveStudentId(
          username
        );

      if (resolvedId !== null) {
        currentStudentId =
          resolvedId;

        setStudentId(
          resolvedId
        );

        localStorage.setItem(
          "studentId",
          String(resolvedId)
        );
      }
    }

    if (!currentStudentId) {
      alert(
        "Student information could not be found. Please login again."
      );

      return;
    }

    if (likingId !== null) {
      return;
    }

    const selectedAnnouncement =
      announcements.find(
        (item) =>
          item.id ===
          announcementId
      );

    if (!selectedAnnouncement) {
      return;
    }

    setLikingId(
      announcementId
    );

    try {
      if (
        selectedAnnouncement.likedByMe
      ) {
        const { error } =
          await supabase
            .from(
              "announcement_likes"
            )
            .delete()
            .eq(
              "announcement_id",
              announcementId
            )
            .eq(
              "student_id",
              currentStudentId
            );

        if (error) {
          console.error(
            "Unlike error:",
            error
          );

          alert(
            `Could not remove like: ${error.message}`
          );

          return;
        }

        setAnnouncements(
          (previous) =>
            previous.map(
              (item) =>
                item.id ===
                announcementId
                  ? {
                      ...item,
                      likedByMe:
                        false,
                      likeCount:
                        Math.max(
                          0,
                          item.likeCount - 1
                        ),
                    }
                  : item
            )
        );

        return;
      }

      const { error } =
        await supabase
          .from(
            "announcement_likes"
          )
          .insert({
            announcement_id:
              announcementId,
            student_id:
              currentStudentId,
          });

      if (error) {
        console.error(
          "Like error:",
          error
        );

        if (
          error.code ===
          "23505"
        ) {
          await loadAnnouncements(
            currentStudentId
          );
        } else {
          alert(
            `Could not like announcement: ${error.message}`
          );
        }

        return;
      }

      setAnnouncements(
        (previous) =>
          previous.map(
            (item) =>
              item.id ===
              announcementId
                ? {
                    ...item,
                    likedByMe:
                      true,
                    likeCount:
                      item.likeCount +
                      1,
                  }
                : item
          )
      );
    } catch (error) {
      console.error(
        "Unexpected like error:",
        error
      );
    } finally {
      setLikingId(null);
    }
  }

  function logout() {
    localStorage.removeItem(
      "studentLoggedIn"
    );

    localStorage.removeItem(
      "student_username"
    );

    localStorage.removeItem(
      "studentUsername"
    );

    localStorage.removeItem(
      "studentName"
    );

    localStorage.removeItem(
      "student_name"
    );

    localStorage.removeItem(
      "studentId"
    );

    sessionStorage.clear();

    router.push("/");
  }

  function formatAnnouncementDate(
    date: string
  ) {
    if (!date) {
      return "";
    }

    return new Date(
      date
    ).toLocaleString(
      "en-IN",
      {
        day: "2-digit",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      }
    );
  }

  function isWithinLatest24Hours(
    createdAt: string
  ) {
    const createdTime =
      new Date(
        createdAt
      ).getTime();

    if (
      Number.isNaN(
        createdTime
      )
    ) {
      return false;
    }

    const now =
      Date.now();

    const difference =
      now -
      createdTime;

    return (
      difference >= 0 &&
      difference <
        24 *
          60 *
          60 *
          1000
    );
  }

  const latestAnnouncement =
    announcements.length > 0 &&
    isWithinLatest24Hours(
      announcements[0]
        .created_at
    )
      ? announcements[0]
      : null;

  const firstLetter =
    studentName
      .charAt(0)
      .toUpperCase();

  /*
   * STUDENT DASHBOARD CARDS
   *
   * Existing 7 options are preserved.
   * QUIZ TESTS is added as option number 8.
   */
  const cards: DashboardCard[] =
    [
      {
        icon: "📊",
        title: "My Attendance",
        description:
          "View your current attendance and attendance percentage.",
        path: "/student/attendance",
        className: "blue",
      },
      {
        icon: "📜",
        title: "Attendance History",
        description:
          "Check your previous attendance records and details.",
        path: "/student/attendance-history",
        className: "purple",
      },
      {
        icon: "📅",
        title: "Academic Calendar",
        description:
          "View important academic dates and calendar information.",
        path: "/student/calendar",
        className: "green",
      },
      {
        icon: "📈",
        title: "Reports",
        description:
          "View your attendance reports and performance details.",
        path: "/student/reports",
        className: "orange",
      },
      {
        icon: "💰",
        title: "Fees",
        description:
          "Check your student fee information and payment details.",
        path: "/student/fees",
        className: "pink",
      },
      {
        icon: "📚",
        title: "Homework",
        description:
          "View homework assigned to your class by your teacher.",
        path: "/student/homework",
        className: "indigo",
      },
      {
        icon: "⚙️",
        title: "Settings",
        description:
          "Manage your account, name and password.",
        path: "/student/settings",
        className: "cyan",
      },
      {
        icon: "🧠",
        title: "QUIZ TESTS",
        description:
          "Attempt scheduled quizzes, view your scores and quiz history.",
        path: "/student/quiz-tests",
        className: "quiz",
      },
    ];

  return (
    <>
      <style jsx global>{`
        * {
          box-sizing: border-box;
        }

        html,
        body {
          margin: 0;
          padding: 0;
          width: 100%;
          overflow-x: hidden;
        }

        button {
          -webkit-tap-highlight-color: transparent;
          touch-action: manipulation;
        }

        @media (max-width: 768px) {
          main.student-dashboard-page {
            padding: 8px !important;
          }

          main.student-dashboard-page > div {
            width: 100% !important;
            max-width: 100% !important;
          }

          nav.student-navbar {
            padding: 10px !important;
            border-radius: 14px !important;
            margin-bottom: 10px !important;
            gap: 8px !important;
            flex-wrap: nowrap !important;
          }

          .student-brand-area {
            min-width: 0 !important;
            flex: 1 !important;
            gap: 7px !important;
          }

          .student-brand-icon {
            width: 36px !important;
            height: 36px !important;
            min-width: 36px !important;
            border-radius: 10px !important;
            font-size: 18px !important;
          }

          .student-brand-name {
            font-size: 10px !important;
            letter-spacing: 0.6px !important;
            white-space: nowrap !important;
          }

          .student-brand-sub {
            font-size: 7px !important;
            letter-spacing: 1.2px !important;
            margin-top: 2px !important;
          }

          .student-nav-right {
            gap: 5px !important;
            flex-wrap: nowrap !important;
          }

          .student-clock {
            padding: 7px 8px !important;
            border-radius: 8px !important;
            font-size: 8px !important;
            white-space: nowrap !important;
          }

          .student-logout {
            padding: 8px 9px !important;
            border-radius: 8px !important;
            font-size: 9px !important;
            white-space: nowrap !important;
          }

          section.student-hero {
            min-height: auto !important;
            padding: 18px !important;
            border-radius: 18px !important;
            margin-bottom: 10px !important;
            display: block !important;
          }

          .student-hero-content {
            gap: 11px !important;
            display: flex !important;
            align-items: center !important;
          }

          .student-avatar {
            width: 58px !important;
            height: 58px !important;
            min-width: 58px !important;
            border-radius: 17px !important;
            font-size: 25px !important;
          }

          .student-small-greeting {
            font-size: 7px !important;
            letter-spacing: 1.2px !important;
            margin-bottom: 4px !important;
          }

          .student-welcome-title {
            font-size: 20px !important;
            line-height: 1.15 !important;
          }

          .student-welcome-text {
            margin-top: 5px !important;
            font-size: 9px !important;
            line-height: 1.45 !important;
          }

          .student-username {
            margin-top: 7px !important;
            padding: 5px 7px !important;
            font-size: 8px !important;
            border-radius: 6px !important;
            max-width: 100% !important;
          }

          .student-hero-side {
            margin-top: 12px !important;
            min-width: 0 !important;
            width: 100% !important;
            padding: 8px 10px !important;
            border-radius: 10px !important;
          }

          .student-status-dot {
            width: 8px !important;
            height: 8px !important;
          }

          .student-online-text {
            font-size: 8px !important;
          }

          .student-online-sub {
            font-size: 8px !important;
          }

          section.student-latest-announcement {
            padding: 12px !important;
            border-radius: 15px !important;
            margin-bottom: 10px !important;
          }

          .student-latest-header {
            align-items: flex-start !important;
            margin-bottom: 9px !important;
            gap: 8px !important;
          }

          .student-latest-eyebrow {
            font-size: 7px !important;
            letter-spacing: 1.2px !important;
          }

          .student-latest-title {
            font-size: 17px !important;
          }

          .student-latest-subtitle {
            font-size: 8px !important;
            margin-top: 3px !important;
          }

          .student-latest-badge {
            padding: 6px 7px !important;
            font-size: 7px !important;
            border-radius: 6px !important;
          }

          .student-latest-card {
            padding: 10px !important;
            border-radius: 12px !important;
          }

          .student-announcement-icon {
            width: 34px !important;
            height: 34px !important;
            min-width: 34px !important;
            border-radius: 9px !important;
            font-size: 16px !important;
          }

          .student-announcement-card-top {
            gap: 8px !important;
          }

          .student-announcement-meta {
            gap: 4px !important;
          }

          .student-teacher-badge,
          .student-time-badge {
            padding: 3px 5px !important;
            font-size: 6px !important;
          }

          .student-announcement-date {
            font-size: 7px !important;
          }

          .student-latest-card-title {
            font-size: 14px !important;
            margin-top: 5px !important;
          }

          .student-announcement-message {
            font-size: 9px !important;
            line-height: 1.5 !important;
            margin-top: 5px !important;
          }

          .student-announcement-bottom {
            margin-top: 9px !important;
            padding-top: 8px !important;
            gap: 7px !important;
          }

          .student-everyone-text {
            font-size: 7px !important;
          }

          .student-like-button {
            padding: 6px 8px !important;
            border-radius: 7px !important;
            font-size: 8px !important;
            gap: 4px !important;
          }

          .student-like-count {
            min-width: 15px !important;
            height: 15px !important;
            font-size: 7px !important;
          }

          section.student-announcement-section {
            padding: 12px !important;
            border-radius: 15px !important;
            margin-bottom: 10px !important;
          }

          .student-announcement-header {
            gap: 8px !important;
            align-items: center !important;
          }

          .student-announcement-eyebrow {
            font-size: 7px !important;
            letter-spacing: 1.2px !important;
          }

          .student-announcement-title {
            font-size: 17px !important;
          }

          .student-announcement-subtitle {
            font-size: 8px !important;
            margin-top: 3px !important;
          }

          .student-view-announcements {
            padding: 8px 9px !important;
            font-size: 8px !important;
            border-radius: 7px !important;
            white-space: nowrap !important;
          }

          section.student-notice {
            padding: 10px !important;
            border-radius: 13px !important;
            margin-bottom: 12px !important;
            gap: 8px !important;
          }

          .student-notice-icon {
            width: 32px !important;
            height: 32px !important;
            min-width: 32px !important;
            border-radius: 8px !important;
            font-size: 15px !important;
          }

          .student-notice-title {
            font-size: 9px !important;
          }

          .student-notice-text {
            font-size: 7px !important;
            line-height: 1.4 !important;
            margin-top: 2px !important;
          }

          .student-section-heading {
            margin-bottom: 8px !important;
            gap: 7px !important;
          }

          .student-section-eyebrow {
            font-size: 7px !important;
            letter-spacing: 1.2px !important;
          }

          .student-section-title {
            font-size: 18px !important;
          }

          .student-service-count {
            padding: 6px 7px !important;
            border-radius: 7px !important;
            font-size: 7px !important;
            white-space: nowrap !important;
          }

          .student-card-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
            gap: 8px !important;
          }

          .student-service-card {
            border-radius: 13px !important;
            min-width: 0 !important;
          }

          .student-card-top {
            padding: 9px !important;
          }

          .student-card-icon {
            width: 34px !important;
            height: 34px !important;
            border-radius: 10px !important;
            font-size: 17px !important;
          }

          .student-card-arrow {
            width: 23px !important;
            height: 23px !important;
            font-size: 12px !important;
          }

          .student-card-body {
            padding: 10px !important;
          }

          .student-card-title {
            font-size: 11px !important;
            line-height: 1.2 !important;
          }

          .student-card-description {
            margin-top: 4px !important;
            font-size: 7px !important;
            line-height: 1.4 !important;
            min-height: 30px !important;
          }

          .student-open-link {
            margin-top: 7px !important;
            font-size: 8px !important;
          }

          section.student-bottom-panel {
            margin-top: 12px !important;
            padding: 10px !important;
            border-radius: 13px !important;
            gap: 8px !important;
          }

          .student-bottom-icon {
            width: 34px !important;
            height: 34px !important;
            border-radius: 9px !important;
            font-size: 16px !important;
          }

          .student-bottom-text {
            min-width: 0 !important;
          }

          .student-bottom-title {
            font-size: 9px !important;
          }

          .student-bottom-description {
            font-size: 7px !important;
            line-height: 1.35 !important;
            margin-top: 2px !important;
          }

          .student-profile-button {
            padding: 7px 8px !important;
            border-radius: 7px !important;
            font-size: 8px !important;
            white-space: nowrap !important;
          }

          footer.student-footer {
            margin-top: 12px !important;
            padding: 10px 2px !important;
            font-size: 7px !important;
          }
        }

        @media (max-width: 380px) {
          main.student-dashboard-page {
            padding: 6px !important;
          }

          .student-brand-name {
            font-size: 9px !important;
          }

          .student-clock {
            display: none !important;
          }

          .student-welcome-title {
            font-size: 18px !important;
          }

          .student-welcome-text {
            font-size: 8px !important;
          }

          .student-card-grid {
            gap: 6px !important;
          }

          .student-card-top {
            padding: 8px !important;
          }

          .student-card-body {
            padding: 9px !important;
          }

          .student-card-title {
            font-size: 10px !important;
          }

          .student-card-description {
            font-size: 6.5px !important;
          }

          .student-view-announcements {
            font-size: 7px !important;
            padding: 7px 8px !important;
          }
        }

        @media (min-width: 769px) and (max-width: 1050px) {
          .student-card-grid {
            grid-template-columns: repeat(
              2,
              minmax(0,1fr)
            ) !important;
          }

          .student-hero {
            padding: 25px !important;
          }

          .student-welcome-title {
            font-size: 26px !important;
          }
        }
      `}</style>

      <main
        className="student-dashboard-page"
        style={styles.page}
      >
        <div style={styles.container}>
          <nav
            className="student-navbar"
            style={styles.navbar}
          >
            <div
              className="student-brand-area"
              style={styles.brandArea}
            >
              <div
                className="student-brand-icon"
                style={styles.brandIcon}
              >
                🎓
              </div>

              <div>
                <div
                  className="student-brand-name"
                  style={styles.brandName}
                >
                  ATTENDANCE PORTAL
                </div>

                <div
                  className="student-brand-sub"
                  style={styles.brandSub}
                >
                  STUDENT CENTER
                </div>
              </div>
            </div>

            <div
              className="student-nav-right"
              style={styles.navRight}
            >
              <div
                className="student-clock"
                style={styles.clock}
              >
                🕒 {time}
              </div>

              <button
                type="button"
                onClick={logout}
                className="student-logout"
                style={styles.logoutButton}
              >
                Logout
              </button>
            </div>
          </nav>

          <section
            className="student-hero"
            style={styles.hero}
          >
            <div style={styles.heroGlowOne} />
            <div style={styles.heroGlowTwo} />

            <div
              className="student-hero-content"
              style={styles.heroContent}
            >
              <div
                className="student-avatar"
                style={styles.avatar}
              >
                {profileImage ? (
                  <img
                    src={profileImage}
                    alt={`${studentName} profile`}
                    style={styles.profileImage}
                    onError={() =>
                      setProfileImage(null)
                    }
                  />
                ) : (
                  firstLetter
                )}
              </div>

              <div style={styles.welcomeArea}>
                <div
                  className="student-small-greeting"
                  style={styles.smallGreeting}
                >
                  STUDENT DASHBOARD
                </div>

                <h1
                  className="student-welcome-title"
                  style={styles.welcomeTitle}
                >
                  Welcome, {studentName}
                </h1>

                <p
                  className="student-welcome-text"
                  style={styles.welcomeText}
                >
                  Manage your attendance,
                  academic information,
                  homework, reports, fees
                  and account settings from
                  one place.
                </p>

                {username && (
                  <div
                    className="student-username"
                    style={styles.usernameBadge}
                  >
                    Username: {username}
                  </div>
                )}
              </div>
            </div>

            <div
              className="student-hero-side"
              style={styles.heroSide}
            >
              <div
                className="student-status-dot"
                style={styles.statusDot}
              />

              <div>
                <div
                  className="student-online-text"
                  style={styles.onlineText}
                >
                  ACCOUNT ACTIVE
                </div>

                <div
                  className="student-online-sub"
                  style={styles.onlineSub}
                >
                  Student Portal
                </div>
              </div>
            </div>
          </section>

          {!announcementLoading &&
            latestAnnouncement && (
              <section
                className="student-latest-announcement"
                style={
                  styles.latestAnnouncementSection
                }
              >
                <div
                  className="student-latest-header"
                  style={
                    styles.latestAnnouncementHeader
                  }
                >
                  <div>
                    <div
                      className="student-latest-eyebrow"
                      style={
                        styles.latestAnnouncementEyebrow
                      }
                    >
                      🔔 NEW ANNOUNCEMENT
                    </div>

                    <h2
                      className="student-latest-title"
                      style={
                        styles.latestAnnouncementTitle
                      }
                    >
                      Latest Announcement
                    </h2>

                    <p
                      className="student-latest-subtitle"
                      style={
                        styles.latestAnnouncementSubtitle
                      }
                    >
                      This announcement will stay
                      here for 24 hours.
                    </p>
                  </div>

                  <div
                    className="student-latest-badge"
                    style={
                      styles.latestAnnouncementBadge
                    }
                  >
                    NEW • 24 HOURS
                  </div>
                </div>

                <article
                  className="student-latest-card"
                  style={
                    styles.latestAnnouncementCard
                  }
                >
                  <div
                    className="student-announcement-card-top"
                    style={
                      styles.announcementCardTop
                    }
                  >
                    <div
                      className="student-announcement-icon"
                      style={
                        styles.latestAnnouncementIcon
                      }
                    >
                      🔔
                    </div>

                    <div
                      style={
                        styles.announcementCardContent
                      }
                    >
                      <div
                        className="student-announcement-meta"
                        style={
                          styles.announcementMeta
                        }
                      >
                        <span
                          className="student-teacher-badge"
                          style={
                            styles.latestTeacherBadge
                          }
                        >
                          TEACHER
                        </span>

                        <span
                          className="student-time-badge"
                          style={
                            styles.latestTimeBadge
                          }
                        >
                          LATEST
                        </span>

                        <span
                          className="student-announcement-date"
                          style={
                            styles.announcementDate
                          }
                        >
                          {formatAnnouncementDate(
                            latestAnnouncement.created_at
                          )}
                        </span>
                      </div>

                      <h3
                        className="student-latest-card-title"
                        style={
                          styles.latestAnnouncementCardTitle
                        }
                      >
                        {
                          latestAnnouncement.title
                        }
                      </h3>

                      <p
                        className="student-announcement-message"
                        style={
                          styles.announcementMessage
                        }
                      >
                        {
                          latestAnnouncement.message
                        }
                      </p>
                    </div>
                  </div>

                  <div
                    className="student-announcement-bottom"
                    style={
                      styles.announcementBottom
                    }
                  >
                    <div
                      className="student-everyone-text"
                      style={
                        styles.everyoneText
                      }
                    >
                      👥 For all students
                    </div>

                    <button
                      type="button"
                      onClick={() =>
                        toggleLike(
                          latestAnnouncement.id
                        )
                      }
                      disabled={
                        likingId ===
                        latestAnnouncement.id
                      }
                      className="student-like-button"
                      style={{
                        ...styles.likeButton,
                        ...(latestAnnouncement.likedByMe
                          ? styles.likeButtonActive
                          : {}),
                        opacity:
                          likingId ===
                          latestAnnouncement.id
                            ? 0.65
                            : 1,
                        cursor:
                          likingId ===
                          latestAnnouncement.id
                            ? "not-allowed"
                            : "pointer",
                      }}
                    >
                      {latestAnnouncement.likedByMe
                        ? "❤️ Liked"
                        : "🤍 Like"}

                      <span
                        className="student-like-count"
                        style={
                          styles.likeCount
                        }
                      >
                        {
                          latestAnnouncement.likeCount
                        }
                      </span>
                    </button>
                  </div>
                </article>
              </section>
            )}

          <section
            className="student-announcement-section"
            style={
              styles.announcementSection
            }
          >
            <div
              className="student-announcement-header"
              style={
                styles.announcementHeader
              }
            >
              <div>
                <div
                  className="student-announcement-eyebrow"
                  style={
                    styles.announcementEyebrow
                  }
                >
                  📢 IMPORTANT
                </div>

                <h2
                  className="student-announcement-title"
                  style={
                    styles.announcementTitle
                  }
                >
                  Announcements
                </h2>

                <p
                  className="student-announcement-subtitle"
                  style={
                    styles.announcementSubtitle
                  }
                >
                  All teacher updates are
                  available here.
                </p>
              </div>

              <button
                type="button"
                onClick={() =>
                  router.push(
                    "/student/announcements"
                  )
                }
                className="student-view-announcements"
                style={
                  styles.viewAnnouncementsButton
                }
              >
                View All →
              </button>
            </div>
          </section>

          <section
            className="student-notice"
            style={styles.notice}
          >
            <div
              className="student-notice-icon"
              style={styles.noticeIcon}
            >
              ℹ️
            </div>

            <div>
              <div
                className="student-notice-title"
                style={styles.noticeTitle}
              >
                Student Information Center
              </div>

              <p
                className="student-notice-text"
                style={styles.noticeText}
              >
                Use the options below to check
                your attendance, academic
                calendar, homework, reports,
                fees, quiz tests and account
                settings.
              </p>
            </div>
          </section>

          <section>
            <div
              className="student-section-heading"
              style={styles.sectionHeading}
            >
              <div>
                <div
                  className="student-section-eyebrow"
                  style={styles.sectionEyebrow}
                >
                  STUDENT SERVICES
                </div>

                <h2
                  className="student-section-title"
                  style={styles.sectionTitle}
                >
                  Your Dashboard
                </h2>
              </div>

              <div
                className="student-service-count"
                style={styles.serviceCount}
              >
                {cards.length} OPTIONS
              </div>
            </div>

            <div
              className="student-card-grid"
              style={styles.cardGrid}
            >
              {cards.map((card) => {
                const styleKey =
                  `card${card.className
                    .charAt(0)
                    .toUpperCase()}${card.className.slice(
                    1
                  )}`;

                return (
                  <button
                    key={card.path}
                    type="button"
                    onClick={() =>
                      router.push(
                        card.path
                      )
                    }
                    className="student-service-card"
                    style={
                      styles.serviceCard
                    }
                  >
                    <div
                      className="student-card-top"
                      style={{
                        ...styles.cardTop,
                        ...(styles[
                          styleKey
                        ] || {}),
                      }}
                    >
                      <div
                        className="student-card-icon"
                        style={
                          styles.cardIcon
                        }
                      >
                        {card.icon}
                      </div>

                      <div
                        className="student-card-arrow"
                        style={
                          styles.arrow
                        }
                      >
                        →
                      </div>
                    </div>

                    <div
                      className="student-card-body"
                      style={
                        styles.cardBody
                      }
                    >
                      <h3
                        className="student-card-title"
                        style={
                          styles.cardTitle
                        }
                      >
                        {card.title}
                      </h3>

                      <p
                        className="student-card-description"
                        style={
                          styles.cardDescription
                        }
                      >
                        {card.description}
                      </p>

                      <div
                        className="student-open-link"
                        style={
                          styles.openLink
                        }
                      >
                        <span>
                          Open
                        </span>

                        <span>
                          →
                        </span>
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </section>

          <section
            className="student-bottom-panel"
            style={
              styles.bottomPanel
            }
          >
            <div
              className="student-bottom-icon"
              style={
                styles.bottomIcon
              }
            >
              👤
            </div>

            <div
              className="student-bottom-text"
              style={
                styles.bottomText
              }
            >
              <h3
                className="student-bottom-title"
                style={
                  styles.bottomTitle
                }
              >
                Keep your profile updated
              </h3>

              <p
                className="student-bottom-description"
                style={
                  styles.bottomDescription
                }
              >
                Your personal information is
                managed through your student
                profile.
              </p>
            </div>

            <button
              type="button"
              onClick={() =>
                router.push(
                  "/student/profile"
                )
              }
              className="student-profile-button"
              style={
                styles.profileButton
              }
            >
              View Profile →
            </button>
          </section>

          <footer
            className="student-footer"
            style={styles.footer}
          >
            <div
              style={styles.footerBrand}
            >
              🎓 Attendance Portal
            </div>

            <div>
              Student Portal • 2026
            </div>
          </footer>
        </div>
      </main>
    </>
  );
}

const styles: {
  [key: string]: React.CSSProperties;
} = {
  page: {
    minHeight: "100vh",
    width: "100%",
    background:
      "linear-gradient(135deg,#f8fafc 0%,#eef2ff 50%,#f0f9ff 100%)",
    padding: "18px",
    boxSizing: "border-box",
    fontFamily:
      "Arial, Helvetica, sans-serif",
    color: "#0f172a",
    overflowX: "hidden",
  },

  container: {
    width: "100%",
    maxWidth: "1250px",
    margin: "0 auto",
  },

  navbar: {
    background: "#ffffff",
    border: "1px solid #e2e8f0",
    borderRadius: "18px",
    padding: "14px 18px",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: "15px",
    marginBottom: "18px",
    boxShadow:
      "0 8px 25px rgba(15,23,42,0.06)",
    flexWrap: "wrap",
  },

  brandArea: {
    display: "flex",
    alignItems: "center",
    gap: "11px",
  },

  brandIcon: {
    width: "45px",
    height: "45px",
    borderRadius: "13px",
    background:
      "linear-gradient(135deg,#2563eb,#7c3aed)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: "22px",
  },

  brandName: {
    fontSize: "13px",
    fontWeight: 1000,
    letterSpacing: "1px",
    color: "#172554",
  },

  brandSub: {
    marginTop: "3px",
    fontSize: "9px",
    fontWeight: 900,
    letterSpacing: "2px",
    color: "#64748b",
  },

  navRight: {
    display: "flex",
    alignItems: "center",
    gap: "10px",
    flexWrap: "wrap",
  },

  clock: {
    background: "#f8fafc",
    border: "1px solid #e2e8f0",
    padding: "9px 12px",
    borderRadius: "9px",
    color: "#475569",
    fontSize: "11px",
    fontWeight: 800,
  },

  logoutButton: {
    border: "none",
    background: "#0f172a",
    color: "#ffffff",
    padding: "10px 15px",
    borderRadius: "9px",
    fontWeight: 900,
    cursor: "pointer",
  },

  hero: {
    position: "relative",
    overflow: "hidden",
    background:
      "linear-gradient(135deg,#172554,#2563eb,#4f46e5)",
    borderRadius: "25px",
    padding: "34px",
    minHeight: "220px",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: "25px",
    marginBottom: "18px",
    boxShadow:
      "0 18px 45px rgba(37,99,235,0.22)",
    boxSizing: "border-box",
  },

  heroGlowOne: {
    position: "absolute",
    width: "230px",
    height: "230px",
    borderRadius: "50%",
    background:
      "rgba(255,255,255,0.08)",
    right: "120px",
    top: "-100px",
  },

  heroGlowTwo: {
    position: "absolute",
    width: "180px",
    height: "180px",
    borderRadius: "50%",
    background:
      "rgba(255,255,255,0.06)",
    right: "-40px",
    bottom: "-90px",
  },

  heroContent: {
    position: "relative",
    zIndex: 2,
    display: "flex",
    alignItems: "center",
    gap: "20px",
    minWidth: 0,
  },

  avatar: {
    width: "88px",
    height: "88px",
    minWidth: "88px",
    borderRadius: "24px",
    background: "#ffffff",
    color: "#2563eb",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: "38px",
    fontWeight: 1000,
    boxShadow:
      "0 12px 30px rgba(0,0,0,0.18)",
    overflow: "hidden",
  },

  profileImage: {
    width: "100%",
    height: "100%",
    objectFit: "cover",
    display: "block",
  },

  welcomeArea: {
    minWidth: 0,
  },

  smallGreeting: {
    color: "#bfdbfe",
    fontSize: "10px",
    fontWeight: 1000,
    letterSpacing: "2px",
    marginBottom: "8px",
  },

  welcomeTitle: {
    margin: 0,
    color: "#ffffff",
    fontSize: "30px",
    lineHeight: 1.2,
    fontWeight: 1000,
    wordBreak: "break-word",
  },

  welcomeText: {
    margin: "9px 0 0",
    color: "#dbeafe",
    fontSize: "13px",
    fontWeight: 600,
    lineHeight: 1.6,
    maxWidth: "600px",
  },

  usernameBadge: {
    display: "inline-block",
    marginTop: "13px",
    padding: "7px 11px",
    borderRadius: "8px",
    background:
      "rgba(255,255,255,0.13)",
    border:
      "1px solid rgba(255,255,255,0.22)",
    color: "#ffffff",
    fontSize: "11px",
    fontWeight: 900,
    maxWidth: "100%",
    wordBreak: "break-word",
  },

  heroSide: {
    position: "relative",
    zIndex: 2,
    background:
      "rgba(255,255,255,0.12)",
    border:
      "1px solid rgba(255,255,255,0.2)",
    borderRadius: "14px",
    padding: "13px 15px",
    display: "flex",
    alignItems: "center",
    gap: "9px",
    minWidth: "155px",
  },

  statusDot: {
    width: "10px",
    height: "10px",
    borderRadius: "50%",
    background: "#4ade80",
    boxShadow:
      "0 0 0 5px rgba(74,222,128,0.15)",
  },

  onlineText: {
    color: "#ffffff",
    fontSize: "10px",
    fontWeight: 1000,
    letterSpacing: "1px",
  },

  onlineSub: {
    marginTop: "3px",
    color: "#bfdbfe",
    fontSize: "10px",
    fontWeight: 700,
  },

  latestAnnouncementSection: {
    background:
      "linear-gradient(135deg,#eff6ff,#ffffff)",
    border:
      "2px solid #93c5fd",
    borderRadius: "20px",
    padding: "20px",
    marginBottom: "18px",
    boxShadow:
      "0 10px 30px rgba(37,99,235,0.10)",
  },

  latestAnnouncementHeader: {
    display: "flex",
    alignItems: "flex-end",
    justifyContent: "space-between",
    gap: "15px",
    marginBottom: "16px",
    flexWrap: "wrap",
  },

  latestAnnouncementEyebrow: {
    color: "#2563eb",
    fontSize: "9px",
    fontWeight: 1000,
    letterSpacing: "2px",
    marginBottom: "4px",
  },

  latestAnnouncementTitle: {
    margin: 0,
    color: "#172554",
    fontSize: "24px",
    fontWeight: 1000,
  },

  latestAnnouncementSubtitle: {
    margin: "5px 0 0",
    color: "#64748b",
    fontSize: "11px",
    fontWeight: 600,
  },

  latestAnnouncementBadge: {
    background: "#2563eb",
    color: "#ffffff",
    border:
      "1px solid #1d4ed8",
    padding: "8px 11px",
    borderRadius: "9px",
    fontSize: "10px",
    fontWeight: 1000,
  },

  latestAnnouncementCard: {
    background: "#ffffff",
    border:
      "1px solid #bfdbfe",
    borderRadius: "16px",
    padding: "16px",
    boxShadow:
      "0 6px 20px rgba(37,99,235,0.07)",
  },

  latestAnnouncementIcon: {
    width: "45px",
    height: "45px",
    minWidth: "45px",
    borderRadius: "12px",
    background:
      "linear-gradient(135deg,#dbeafe,#bfdbfe)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: "21px",
  },

  latestTeacherBadge: {
    background: "#dbeafe",
    color: "#1d4ed8",
    padding: "4px 7px",
    borderRadius: "6px",
    fontSize: "8px",
    fontWeight: 1000,
    letterSpacing: "0.7px",
  },

  latestTimeBadge: {
    background: "#dcfce7",
    color: "#15803d",
    padding: "4px 7px",
    borderRadius: "6px",
    fontSize: "8px",
    fontWeight: 1000,
    letterSpacing: "0.5px",
  },

  latestAnnouncementCardTitle: {
    margin: "7px 0 0",
    color: "#172554",
    fontSize: "18px",
    fontWeight: 1000,
    wordBreak: "break-word",
  },

  announcementSection: {
    background: "#ffffff",
    border: "1px solid #dbeafe",
    borderRadius: "20px",
    padding: "20px",
    marginBottom: "25px",
    boxShadow:
      "0 8px 26px rgba(15,23,42,0.06)",
  },

  announcementHeader: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: "15px",
    flexWrap: "wrap",
  },

  announcementEyebrow: {
    color: "#2563eb",
    fontSize: "9px",
    fontWeight: 1000,
    letterSpacing: "2px",
    marginBottom: "4px",
  },

  announcementTitle: {
    margin: 0,
    color: "#172554",
    fontSize: "24px",
    fontWeight: 1000,
  },

  announcementSubtitle: {
    margin: "5px 0 0",
    color: "#64748b",
    fontSize: "11px",
    fontWeight: 600,
  },

  viewAnnouncementsButton: {
    border: "none",
    background: "#2563eb",
    color: "#ffffff",
    padding: "10px 15px",
    borderRadius: "9px",
    fontSize: "11px",
    fontWeight: 1000,
    cursor: "pointer",
    boxShadow:
      "0 5px 15px rgba(37,99,235,0.18)",
  },

  announcementCardTop: {
    display: "flex",
    alignItems: "flex-start",
    gap: "13px",
  },

  announcementCardContent: {
    minWidth: 0,
    flex: 1,
  },

  announcementMeta: {
    display: "flex",
    alignItems: "center",
    gap: "8px",
    flexWrap: "wrap",
  },

  announcementDate: {
    color: "#94a3b8",
    fontSize: "9px",
    fontWeight: 700,
  },

  announcementMessage: {
    margin: "7px 0 0",
    color: "#475569",
    fontSize: "12px",
    lineHeight: 1.65,
    fontWeight: 600,
    whiteSpace: "pre-wrap",
    wordBreak: "break-word",
  },

  announcementBottom: {
    marginTop: "14px",
    paddingTop: "12px",
    borderTop:
      "1px solid #e2e8f0",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: "10px",
    flexWrap: "wrap",
  },

  everyoneText: {
    color: "#64748b",
    fontSize: "10px",
    fontWeight: 800,
  },

  likeButton: {
    border: "1px solid #cbd5e1",
    background: "#ffffff",
    color: "#475569",
    padding: "8px 11px",
    borderRadius: "9px",
    fontSize: "11px",
    fontWeight: 1000,
    display: "flex",
    alignItems: "center",
    gap: "7px",
  },

  likeButtonActive: {
    background: "#fff1f2",
    border:
      "1px solid #fecdd3",
    color: "#be123c",
  },

  likeCount: {
    background: "#f1f5f9",
    color: "#475569",
    minWidth: "19px",
    height: "19px",
    padding: "0 4px",
    borderRadius: "999px",
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: "9px",
    fontWeight: 1000,
  },

  notice: {
    background: "#ffffff",
    border: "1px solid #dbeafe",
    borderRadius: "17px",
    padding: "15px 18px",
    display: "flex",
    alignItems: "center",
    gap: "13px",
    marginBottom: "25px",
    boxShadow:
      "0 7px 22px rgba(15,23,42,0.05)",
  },

  noticeIcon: {
    width: "40px",
    height: "40px",
    minWidth: "40px",
    borderRadius: "11px",
    background: "#eff6ff",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: "19px",
  },

  noticeTitle: {
    color: "#172554",
    fontSize: "13px",
    fontWeight: 900,
  },

  noticeText: {
    margin: "3px 0 0",
    color: "#64748b",
    fontSize: "11px",
    lineHeight: 1.5,
    fontWeight: 600,
  },

  sectionHeading: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "flex-end",
    gap: "15px",
    marginBottom: "15px",
  },

  sectionEyebrow: {
    color: "#2563eb",
    fontSize: "9px",
    fontWeight: 1000,
    letterSpacing: "2px",
    marginBottom: "3px",
  },

  sectionTitle: {
    margin: 0,
    fontSize: "24px",
    fontWeight: 1000,
    color: "#172554",
  },

  serviceCount: {
    background: "#ffffff",
    border: "1px solid #e2e8f0",
    color: "#64748b",
    padding: "8px 11px",
    borderRadius: "9px",
    fontSize: "10px",
    fontWeight: 900,
  },

  cardGrid: {
    display: "grid",
    gridTemplateColumns:
      "repeat(3,minmax(0,1fr))",
    gap: "15px",
  },

  serviceCard: {
    border: "1px solid #e2e8f0",
    background: "#ffffff",
    borderRadius: "19px",
    overflow: "hidden",
    padding: 0,
    textAlign: "left",
    cursor: "pointer",
    boxShadow:
      "0 7px 22px rgba(15,23,42,0.05)",
    minWidth: 0,
  },

  cardTop: {
    padding: "15px",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
  },

  cardBlue: {
    background:
      "linear-gradient(135deg,#dbeafe,#bfdbfe)",
  },

  cardPurple: {
    background:
      "linear-gradient(135deg,#ede9fe,#ddd6fe)",
  },

  cardGreen: {
    background:
      "linear-gradient(135deg,#dcfce7,#bbf7d0)",
  },

  cardOrange: {
    background:
      "linear-gradient(135deg,#ffedd5,#fed7aa)",
  },

  cardPink: {
    background:
      "linear-gradient(135deg,#fce7f3,#fbcfe8)",
  },

  cardIndigo: {
    background:
      "linear-gradient(135deg,#e0e7ff,#c7d2fe)",
  },

  cardCyan: {
    background:
      "linear-gradient(135deg,#cffafe,#a5f3fc)",
  },

  /*
   * QUIZ TESTS CARD DESIGN
   */
  cardQuiz: {
    background:
      "linear-gradient(135deg,#fef9c3,#fde68a)",
  },

  cardIcon: {
    width: "47px",
    height: "47px",
    borderRadius: "14px",
    background:
      "rgba(255,255,255,0.72)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: "23px",
  },

  arrow: {
    width: "30px",
    height: "30px",
    borderRadius: "50%",
    background:
      "rgba(255,255,255,0.65)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    color: "#172554",
    fontWeight: 1000,
  },

  cardBody: {
    padding: "17px",
  },

  cardTitle: {
    margin: 0,
    color: "#172554",
    fontSize: "17px",
    fontWeight: 1000,
  },

  cardDescription: {
    margin: "7px 0 0",
    color: "#64748b",
    fontSize: "11px",
    lineHeight: 1.6,
    minHeight: "36px",
    fontWeight: 600,
  },

  openLink: {
    marginTop: "13px",
    color: "#2563eb",
    fontSize: "11px",
    fontWeight: 1000,
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
  },

  bottomPanel: {
    marginTop: "20px",
    background:
      "linear-gradient(135deg,#ffffff,#f8fafc)",
    border: "1px solid #e2e8f0",
    borderRadius: "18px",
    padding: "17px",
    display: "flex",
    alignItems: "center",
    gap: "13px",
    boxShadow:
      "0 7px 22px rgba(15,23,42,0.05)",
    flexWrap: "wrap",
  },

  bottomIcon: {
    width: "48px",
    height: "48px",
    borderRadius: "13px",
    background: "#eef2ff",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: "23px",
  },

  bottomText: {
    flex: 1,
    minWidth: "200px",
  },

  bottomTitle: {
    margin: 0,
    color: "#172554",
    fontSize: "14px",
    fontWeight: 1000,
  },

  bottomDescription: {
    margin: "4px 0 0",
    color: "#64748b",
    fontSize: "11px",
    fontWeight: 600,
  },

  profileButton: {
    border: "none",
    background: "#2563eb",
    color: "#ffffff",
    padding: "10px 15px",
    borderRadius: "9px",
    fontWeight: 900,
    cursor: "pointer",
  },

  footer: {
    marginTop: "25px",
    padding: "18px 5px",
    borderTop: "1px solid #e2e8f0",
    display: "flex",
    justifyContent: "space-between",
    gap: "10px",
    color: "#94a3b8",
    fontSize: "10px",
    fontWeight: 700,
    flexWrap: "wrap",
  },

  footerBrand: {
    color: "#475569",
    fontWeight: 900,
  },
};