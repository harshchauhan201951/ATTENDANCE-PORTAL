self.addEventListener("push", function (event) {
  let data = {};

  try {
    data = event.data ? event.data.json() : {};
  } catch (error) {
    console.error("Push notification data error:", error);
  }

  const title = data.title || "RACER ACADEMY";

  const options = {
    body:
      data.message ||
      data.body ||
      "You have a new announcement.",

    // RACER ACADEMY notification icon
    icon: "/notification-icon.png",
    badge: "/notification-icon.png",

    // Notification silent nahi hogi
    silent: false,

    // Vibration
    vibrate: [300, 150, 300],

    // New notification ko alert karne ke liye
    renotify: true,

    tag: "racer-academy-announcement",

    requireInteraction: false,

    // Announcement notification ka fixed destination
    // Server se aane wala URL intentionally ignore kiya gaya hai.
    data: {
      url: "/student/dashboard",
    },

    actions: [
      {
        action: "open",
        title: "Open",
      },
    ],
  };

  event.waitUntil(
    self.registration.showNotification(title, options)
  );
});

self.addEventListener(
  "notificationclick",
  function (event) {
    event.notification.close();

    // Announcement notification hamesha
    // Student Dashboard par jayegi.
    const url = "/student/dashboard";

    event.waitUntil(
      clients
        .matchAll({
          type: "window",
          includeUncontrolled: true,
        })
        .then(function (clientList) {
          for (const client of clientList) {
            if ("focus" in client) {
              client.navigate(url);
              return client.focus();
            }
          }

          if (clients.openWindow) {
            return clients.openWindow(url);
          }

          return undefined;
        })
    );
  }
);